import ActionsView from '@/components/views/actions-view';

export default function Dashboard() {
  return <ActionsView />;
}
