const PromptsPage = () => {
  return (
    <div className="text-center text-text-secondary">
      Content for Prompts tab
    </div>
  );
};

export default PromptsPage;
