const AnalyticsPage = () => {
  return (
    <div className="text-center text-text-secondary">
      Content for Analytics tab
    </div>
  );
};

export default AnalyticsPage;
