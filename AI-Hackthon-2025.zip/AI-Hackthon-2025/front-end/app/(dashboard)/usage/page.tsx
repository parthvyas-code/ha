const UsagePage = () => {
  return (
    <div className="text-center text-text-secondary">Content for Usage tab</div>
  );
};

export default UsagePage;
