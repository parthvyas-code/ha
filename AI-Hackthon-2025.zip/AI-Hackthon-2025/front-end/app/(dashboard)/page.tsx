import { DashboardView } from '@/components/views/dashboard-view';

export default function Dashboard() {
  return <DashboardView />;
}
