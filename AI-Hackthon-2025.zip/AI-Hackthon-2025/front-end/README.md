# Orchestrate Frontend

This is the project using the Vercel AI SDK v5.

## Getting Started

1. Install dependencies:

```bash
npm install
```

2. Set up your environment variables:

```bash
cp .env.example .env.local
```

Add your Anthropic API key to `.env.local`:

```
OPENAI_API_KEY=your-api-key-here
```

3. Run the development server:

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) to see the result.

## Key Features

- Uses the new AI SDK v5 with `@ai-sdk/react` and `@ai-sdk/anthropic`
- Integrates with `@assistant-ui/react` using the new `useChatRuntime` hook
- No RSC support (client-side only)
- Simplified integration with the `useChatRuntime` hook that wraps AI SDK v5's `useChat`
- Automatically uses `AssistantChatTransport` to pass system messages and frontend tools to the backend

## Custom Transport Configuration

By default, `useChatRuntime` uses `AssistantChatTransport` which automatically forwards system messages and frontend tools to the backend.

### Custom API URL with Forwarding

When customizing the API URL, you must explicitly use `AssistantChatTransport` to keep system/tools forwarding:

```typescript
import { AssistantChatTransport } from "@assistant-ui/react-ai-sdk";

const runtime = useChatRuntime({
  transport: new AssistantChatTransport({
    api: "/my-custom-api/chat", // Custom URL with system/tools forwarding
  }),
});
```

### Disable System/Tools Forwarding

To use the standard AI SDK transport without forwarding:

```typescript
import { DefaultChatTransport } from "ai";

const runtime = useChatRuntime({
  transport: new DefaultChatTransport(), // No system/tools forwarding
});
```

## API Route

The API route at `/api/chat` uses the new `streamText` function from AI SDK v5 to handle chat completions.


## Creating a Custom Agent View

To add a new agent with a custom chat view, follow these steps:

### 1. Add the Agent to `agents.ts`

Open `front-end/constants/agents.ts` and add your new agent object to the `agents` array. For example:

```typescript
{
  id: 'your-agent-id',
  title: 'Your Agent Title',
  description: 'A detailed description of what your agent does and its capabilities.',
  actions: ['View All Actions >'],
  type: 'secondary', // or 'primary' for main agents
  endpoint: 'http://localhost:8006', // Your agent's backend endpoint
}
```

### 2. Create a Custom Chat Component (Optional)

If you need a custom chat interface different from the default `CustomChatView`, create a new component in `front-end/components/agents/`:

```typescript
// front-end/components/agents/your-custom-chat.tsx
'use client';

interface YourCustomChatProps {
  agentId: string;
}

export default function YourCustomChat({ agentId }: YourCustomChatProps) {
  // Your custom chat implementation
  return (
    <div>
      {/* Your custom chat UI */}
    </div>
  );
}
```

### 3. Register the Agent Component

Open `front-end/components/agents/chat.tsx` and add your agent to the `agentComponentMap`:

```typescript
const agentComponentMap = {
  'insights-engine': CustomChatView,
  'account-marketing': CustomChatView,
  'intent-abm': CustomChatView,
  'marketing-brief': CustomChatView,
  'ad-spend': CustomChatView,
  'lead-scoring': CustomChatView,
  'your-agent-id': YourCustomChat, // Add your custom component here
};
```

### 4. Backend Integration

Your agent's backend should implement the following endpoints:

- `POST /chat` - Handle incoming chat messages
- `GET /chat/history?session_id={threadId}` - Return chat history

The expected request/response format:

**POST /chat:**
```json
{
  "session_id": "unique-session-id",
  "message": "user message content"
}
```

**Response:**
```json
{
  "reply": "assistant response content"
}
```

**GET /chat/history:**
```json
{
  "messages": [
    {
      "id": "message-id",
      "content": "message content",
      "role": "user" | "assistant",
      "timestamp": "2024-01-01T00:00:00Z"
    }
  ]
}
```

### 5. Testing Your Agent

1. Start your agent's backend server
2. Navigate to the Agents page in the frontend
3. Click on your agent card to open the chat interface
4. Test the conversation flow
